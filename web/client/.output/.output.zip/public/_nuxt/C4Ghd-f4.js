import"./CbujNTzC.js";const t=""+new URL("1.eBlXY83Y.png",import.meta.url).href;export{t as _};
