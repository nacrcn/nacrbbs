import"./CbujNTzC.js";const s=globalThis.setInterval;export{s};
